^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package gazebo_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.4.14 (2017-06-24)
-------------------

2.4.13 (2017-02-28)
-------------------

2.4.12 (2016-11-27)
-------------------

2.4.11 (2016-07-14)
-------------------
* [gazebo_msgs] fix wrong dependencies
* Contributors: Yuki Furuta

2.4.10 (2016-02-25)
-------------------

2.4.9 (2015-08-16)
------------------

2.4.8 (2015-03-17)
------------------

2.4.7 (2014-12-15)
------------------
* Update Gazebo/ROS tutorial URL
* Contributors: Jose Luis Rivero

2.4.6 (2014-09-01)
------------------

2.4.5 (2014-08-18)
------------------

2.4.4 (2014-07-18)
------------------
* Fix repo names in package.xml's
* Contributors: Jon Binney

2.4.3 (2014-05-12)
------------------

2.4.2 (2014-03-27)
------------------
* merging from hydro-devel
* bump patch version for indigo-devel to 2.4.1
* merging from indigo-devel after 2.3.4 release
* "2.4.0"
* catkin_generate_changelog
* Contributors: John Hsu

2.4.1 (2013-11-13)
------------------
* rerelease because sdformat became libsdformat, but we also based change on 2.3.4 in hydro-devel.

2.4.0 (2013-10-14)
------------------

2.3.5 (2014-03-26)
------------------

2.3.4 (2013-11-13)
------------------

2.3.3 (2013-10-10)
------------------

2.3.2 (2013-09-19)
------------------

2.3.1 (2013-08-27)
------------------

2.3.0 (2013-08-12)
------------------

2.2.1 (2013-07-29)
------------------

2.2.0 (2013-07-29)
------------------

2.1.5 (2013-07-18)
------------------

2.1.4 (2013-07-14)
------------------

2.1.3 (2013-07-13)
------------------

2.1.2 (2013-07-12)
------------------
* Cleaned up CMakeLists.txt for all gazebo_ros_pkgs
* 2.1.1

2.1.1 (2013-07-10 19:11)
------------------------

2.1.0 (2013-06-27)
------------------

2.0.2 (2013-06-20)
------------------

2.0.1 (2013-06-19)
------------------
* Incremented version to 2.0.1

2.0.0 (2013-06-18)
------------------
* Changed version to 2.0.0 based on gazebo_simulator being 1.0.0
* Updated package.xml files for ros.org documentation purposes
* Imported from bitbucket.org
