Ardupilot SITL Gazebo Plugin
============================

The initial implementation of this plugin was licensed under Apache v2.0 terms.

[ALv2]: http://www.apache.org/licenses/LICENSE-2.0

This derivative is licensed under the Creative Commons Attribution-NonCommercial 4.0 International License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/.