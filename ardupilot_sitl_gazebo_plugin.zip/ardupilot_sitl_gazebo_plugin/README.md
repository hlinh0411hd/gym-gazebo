Ardupilot SITL Gazebo Plugin
============================

Plugins to interface Ardupilot SITL with a ROS/Gazebo simulation.

